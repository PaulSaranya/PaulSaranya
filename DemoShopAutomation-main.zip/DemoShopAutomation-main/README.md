# DemoShopAutomation
Please import this as a Maven project. 
Test cases can be executed by running the TestRunner class as a Junit test. 
Please do Maven install all the dependencies will be downloaded in local Results will be available in target/index.html

![image](https://user-images.githubusercontent.com/88542736/128564825-7e56c871-1392-4a06-8df7-bef5299ec2c8.png)


**Defects:**
The "add to wishlist" button is not working in latest chrome version 92.0.4515.131

**Enhancement/Improvements:**
Customise reporting
Integration with CI/CD pipelining
